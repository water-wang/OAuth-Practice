var session = require('express-session');
var app = require('express')();

app.use(session({
    secret: 'session secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 60000 }
}));

app.listen(5000, function () {
    console.log('Client active on port 5000.');
});
