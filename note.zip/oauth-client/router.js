var express = require('express');
var request = require('request');
var uuid = require('node-uuid');
var router = express.Router();

var SERVER_URL = 'http://locahost:3000';
var REDIRECT_SERVER_URL = 'http://locahost:5000';

var CLIENT_ID = 'CLIENTID';

router.get('/', function (req, res) {
    var state = uuid.v4();
    req.session.state = state;

    var options = {
        url: SERVER_URL + '/authorize',
        client_id: CLIENT_ID,
        redirect_uri: REDIRECT_SERVER_URL + '/callback',
        state: state,
        scope: 'openid',
        response_type: 'code',
        user_id: 1
    };

    var authorizationURL = options.url +
        '?redirect_uri=' + options.redirect_uri +
        '&user_id=' + option.user_id +
        '&client_id=' + options.client_id +
        '&scope=' + options.scope +  // switch between OAuth 2 and OpenId Connect
        '&response_type=' + options.response_type +
        '&state=' + options.state;

    res.render('index', {
        authorizationURL: authorizationURL
    });
});

router.get('/callback', function (req, res, next) {
    var state = req.query.state;
    var code = req.query.code;

    // Compare the state with the session's state
    if (state !== req.session.state) {
        next(new Error('State does not match'));
    }

    request.post({
        url: SERVER_URL + '/token',
        form: {
            code: code,
            grant_type: 'authorization_code',
            redirect_uri: REDIRECT_SERVER_URL + '/callback',
            client_id: CLIENT_ID
        }
    }, function (err, res, body) {
        if (err) {
            next(err);
        }

        var resp = JSON.parse(body);
        var accessToken = resp.access_token;

        // Use the Access Token for a protected resource request
    });
})